echo ----------------------------Обнаружение бэкдоров ------------------------------

for((integer = 0; integer <= 0; integer ++))
do
  foo1="python3 univ_bd.py --model_dir model$integer"
  $foo1
done

