echo ----------------------------Обучение чистых моделей ------------------------------

for((integer = 0; integer <= 0; integer ++))
do
  foo2="python3 train.py --model_dir clean$integer"
  $foo2
done

